import { mountDomRenderer } from "react-cosmos-dom";
import * as mountArgs from "../cosmos.imports";
mountDomRenderer(mountArgs);
